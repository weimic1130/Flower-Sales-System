<?php 
include_once("common/init.php");
//发送评论
	if ($_POST){
		if (!$_SESSION["id"]) {
			goBakMsg("登录后才可提交！");
			die;
		}
		$goodid = !empty($_POST['goodid']) ? intval($_POST['goodid']) : '';
		$row2 = db_get_row("select * from orders where  userid=".$_SESSION['id']." and zt='已收货' and instr(CONCAT('@',spc),'@$goodid@')>0");
		if (!$row2["id"]) {
			goBakMsg("您未购买过此商品或订单未完成");
			die;
		}
		else{
			$row3 = db_get_row("select * from comment where  userid=".$_SESSION['id']." and goodid=".$goodid);
			if ($row3["id"]) {
				goBakMsg("您已评论过此商品");
				die;
			}else{
				$data = array();
				$data["userid"] = $_SESSION["id"];
				$data["goodid"] = $_POST["goodid"];
				$data["content"] = "'".$_POST["content"]."'";
				db_add("comment",$data);
				goBakMsg("提交成功！");
				die;
			}
		}
	}
?>