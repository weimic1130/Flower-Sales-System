﻿<?php
include_once("header.php");
check_loginuser();
?>
<script language="javascript">
function chkinput(form){
	if(form.receiver.value==""){
		alert("请输入收货人姓名!");
		form.receiver.select();
		return(false);
	}
	if(form.address.value==""){
		alert("请输入收货人地址!");
		form.address.select();
		return(false);
	}
	if(form.tel.value==""){
		alert("请输入收货人联系电话!");
		form.tel.select();
		return(false);
	}
	if(form.email.value==""){
		alert("请输入收货人E-mail地址!");
		form.email.select();
		return(false);
	}
	if(form.email.value.indexOf("@")<0){
		alert("收货人E-mail地址格式输入错误!");
		form.email.select();
		return(false);
	}
	return(true);
}
</script>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("userleft.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31" class="sort"><a href="index.php">首页</a> &gt;&gt; 收货人信息</td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <table width="720" height="293" border="0" align="left" cellpadding="0" cellspacing="1">
<?php
$info = db_get_row("select * from user where id=".$_SESSION["id"]);
 ?>
            <form name="form1" method="post" action="savedd.php" onSubmit="return chkinput(this)">
              <tr>
                <td width="100" height="32" align="right" bgcolor="#FFFFFF">收货人姓名：</td>
                <td bgcolor="#FFFFFF">
                  <input type="text" name="receiver" size="25" class="text" value="<?php echo $info['nickname'];?>">
                </td>
                </tr>
                <tr>
                <td height="32" align="right" bgcolor="#FFFFFF">性别：</td>
                <td height="25" bgcolor="#FFFFFF">
                   <select name="sex">
					<option value="未知" <?php if($info["sex"]=="未知"){echo "selected";}?>>未知</option>
					<option value="男" <?php if($info["sex"]=="男"){echo "selected";}?>>男</option>
					<option value="女" <?php if($info["sex"]=="女"){echo "selected";}?>>女</option>
					</select>
                </td>
              </tr>
              <tr>
                <td height="32" align="right" bgcolor="#FFFFFF">联系电话：</td>
                <td height="25" bgcolor="#FFFFFF">
                    <input type="text" name="tel" size="25" class="text" value="<?php echo $info['tel'];?>">
                </td>
              </tr>
              <tr>
                <td height="32" align="right" bgcolor="#FFFFFF">电子邮箱：</td>
                <td height="25" bgcolor="#FFFFFF">
                    <input type="text" name="email" size="25" class="text" value="<?php echo $info['email'];?>">
                </td>
              </tr>
              <tr>
                <td height="32" align="right" bgcolor="#FFFFFF">详细地址：</td>
                <td height="25" bgcolor="#FFFFFF">
                    <input name="address" type="text" class="text" size="50" value="<?php echo $info['address'];?>">
                </td>
              </tr>
              <tr>
                <td height="32" align="right" bgcolor="#FFFFFF">送货方式：</td>
                <td height="25" bgcolor="#FFFFFF">
                   <select name="shff" id="shff">
                      <option selected value="普通平邮">普通平邮</option>
                      <option value="特快专递">特快专递</option>
                      <option value="普通快递">普通快递</option>
                      <option selected value="站点自提">站点自提</option>
                    </select>
                </td>
              </tr>
              <tr>
                <td height="32" align="right" bgcolor="#FFFFFF">支付方式：</td>
                <td height="25" bgcolor="#FFFFFF">
                    <select name="zfff" id="zfff">
                      <option selected value="支付宝">支付宝</option>
                      <option value="微信支付">微信支付</option>
                      <option value="财富通">财富通</option>
                    </select>
                </td>
              </tr>
              <tr>
                <td height="86" align="right" bgcolor="#FFFFFF">简单留言：</td>
                <td height="86" bgcolor="#FFFFFF">
                    <textarea name="ly" cols="70" rows="5" class="text"></textarea>
                </td>
              </tr>
              <tr>
                <td height="40" colspan="2" align="center" bgcolor="#FFFFFF">
                    <input name="submit2" type="submit" class="tbutton" value="提交订单">
                </td>
              </tr>
            </form>
        </table>

        </td>
      </tr>
    </table></td>
  </tr>
</table>
<?php
	include_once("footer.php");
?>