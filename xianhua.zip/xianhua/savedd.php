<?php
include_once("common/init.php");
	$info = db_get_row("select * from user where id=".$_SESSION["id"]);//调用用户信息
	$dingdanhao=date("YmjHis").$info['id'];//订单号生成
	$spc=$_SESSION['producelist'];//商品编号id
	$slc= $_SESSION['quatity'];//商品数量信息
	$shouhuoren=$_POST['receiver'];//收货人
	$address=$_POST['address'];//地址
	$tel=$_POST['tel'];//电话
	$email=$_POST['email'];//email
	$shff=$_POST['shff'];//收货方式
	$zfff=$_POST['zfff'];//支付方式
	$xiadanren=$_SESSION['account'];//下单人姓名
	$zt="未付款";
	$total=$_SESSION['total'];
	
	$data = array();
	$data["onumber"] = "'". $dingdanhao ."'";
	$data["userid"] = "'". $info['id'] ."'";
	$data["spc"] = "'". $spc ."'";
	$data["slc"] = "'". $slc ."'";
	$data["tel"] = "'". $tel ."'";
	$data["receiver"] = "'". $shouhuoren ."'";
	$data["address"] = "'". $address ."'";
	$data["sex"] = "'". $_POST["sex"] ."'";
	$data["email"] = "'". $email ."'";
	$data["shff"] = "'". $shff ."'";
	$data["zfff"] = "'". $zfff ."'";
	$data["leaveword"] = "'". $leaveword ."'";
	$data["xname"] = "'". $xiadanren ."'";
	$data["zt"] = "'". $zt ."'";
	$data["total"] = "'". $total ."'";
	db_add("orders", $data);
	$info2=db_get_row("select * from orders where userid=".$info['id']." order by id desc");//调出订单信息
	
	$arraysp=explode("@",$spc);//分割成数组拆分商品
	$arraysl=explode("@",$slc);//分割数组拆分各个商品数量
	
	//循环订单商品,判断库存是否充足
	for($j=0;$j<count($arraysp);$j++){
	$id1=$arraysp[$j];
    $num=$arraysl[$j];
	$gooda=db_get_row("select * from goods where id='".$id1."'");
	if($gooda['amount']<$num){urlMsg($gooda['title']."购买大于库存","cart.php");die;};
	}
	
	
	for($i=0;$i<count($arraysp)-1;$i++){//循环订单商品数组
		if($arraysp[$i]!=""){//不为空时
		$info1=db_get_row("select * from goods where id='".$arraysp[$i]."'");//调用商品信息
		//添加订单商品及数量到订单副表
		$data = array();
		$data["goodid"] = "'".$info1["id"]."'";//商品id
		$data["nums"] = "'".$arraysl[$i]."'";//数量
		$data["price"] = "'".$info1["sprice"]."'";//商品价格
		$data["userid"] = "'".$info["id"]."'";//用户id
		$data["ordersid"] = "'".$info2["id"]."'";//订单id
		$data["categoryid"] = "'".$info1["categoryid"]."'";//商品分类
		$data["addtime"] = "'".date("Y-m-d")."'";//时间
		$data["zt"] = "'未付款'";//状态
		db_add("ordersta",$data);//添加进数据库
		}
		
	}
	urlMsg("订购成功","ordershow.php?id=".$info2['id']);
?>
