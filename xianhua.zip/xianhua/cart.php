<?php
 include_once("header.php");
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31" class="sort"><a href="index.php">首页</a> &gt;&gt; 我的购物车</td>
      </tr>
      <tr>
        <td height="" align="center" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        
        <table width="95%" border="0" cellpadding="0" cellspacing="0">
        <form name="form1" method="post" action="cart.php">
          <tr><td height="10"></td></tr>
          <tr>
            <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" style="border:#d0d0cf 1px solid">
                <?php
			  $_SESSION['total'] = null;//设置session 总数为0
			  $qk = !empty($_GET['qk']) ? trim($_GET['qk']) : ''; //如果是清空购物车
			  if($qk=="yes"){
			     $_SESSION['producelist']="";//商品字符串为空
				 $_SESSION['quatity']=""; //数量字符串为空
			  }
			  $sessionproducelist = !empty($_SESSION['producelist']) ? trim($_SESSION['producelist']) : '';//接收商品列表字符串
			  if(!isset($_SESSION['producelist'])){//如果为空,购物车无商品
					echo "<tr>";
                   echo" <td height='25' colspan='6' bgcolor='#FFFFFF' align='center'>您的购物车为空!</td>";
                   echo"</tr>";
			
			}else{
			   $arraygwc=explode("@",$_SESSION['producelist']);//将购物车商品字符串分割成数组
			   $s=0;
			   for($i=0;$i<count($arraygwc);$i++){//循环数组
			       $s+=intval($arraygwc[$i]);//数组数量想加
			   }
			  if($s==0 ){//0为没有商品
				   echo "<tr>";
                   echo" <td height='25' colspan='6' bgcolor='#FFFFFF' align='center'>您的购物车为空!</td>";
                   echo"</tr>";
				}
			  else{ 
			?>
                <tr bgcolor="#f1f1f1">
                  <td width="125" height="35" align="center">商品名称</div></td>
                  <td width="110" height="35" align="center">数量</td>
                  <td width="64" height="35" align="center">市场价</td>
                  <td width="64" height="35" align="center">会员价</td>
                  <td width="51" height="35" align="center">折扣</td>
                  <td width="66" height="35" align="center">小计</td>
                  <td width="71" height="35" align="center">操作</td>
                </tr>
                <?php
			    $total=0;
			    $array=explode("@",$_SESSION['producelist']);//将购物车商品字符串分割成数组
				$arrayquatity=explode("@",$_SESSION['quatity']);//将购物车商品数量字符串分割成数组
				if($_POST){//修改购物车数量
				while(list($name,$value)=each($_POST)){
					for($i=0;$i<count($array)-1;$i++){
						if(($array[$i])==$name){//循环商品
							$info1 = db_get_row("select * from goods where id='".$array[$i]."'");//调用商品信息
							if($value>$info1['amount']){//判断库存
								echo "<script language='javascript'>alert('购买大于库存，请重新选购数量！');location.href='cart.php';</script>";
								die;
							 }
								  $arrayquatity[$i]=$value; //商品数量赋给数组
								}
							}
						}
						echo "<script>alert('更新成功!');</script>";
				}
			    $_SESSION['quatity']=implode("@",$arrayquatity);//把商品数量用@隔开
				for($i=0;$i<count($array)-1;$i++){ //循环商品
				   $id=$array[$i];//调出商品id
				   $num=$arrayquatity[$i];//调出商品数量
				  if($id!=""){
				   $info = db_get_row("select * from goods where id=".$id);//循环展示商品
				   $total1=$num*$info['sprice'];//计算商品总价
				   $total+=$total1;
				   $_SESSION["total"]=$total;//总价赋给session
			?>
                <tr bgcolor="#FFEDBF">
                  <td height="165" bgcolor="#FFffff"><div align="center"><a href="goodshow.php?id=<?php echo $info['id'];?>&categoryid=<?php echo $info['categoryid'];?>"><img src="<?php echo __PUBLIC__;?>/Upload/<?php echo $info["img"];?>" width="120" height="120"/></a></div></td>
                  <td height="35" bgcolor="#FFffff" align="center">
                        <div class="gw_num" style="border: 1px solid #dbdbdb;width: 110px;line-height: 26px;overflow: hidden;">
                            <em class="jian">-</em>
                            <input type="text" name="<?php echo $info['id'];?>" value="<?php echo $num;?>" class="num"/>
                            <em class="add">+</em>
                        </div>
                 </td>
                  <td height="35" bgcolor="#FFffff"><div align="center"><?php echo $info['mprice'];?>元</div></td>
                  <td height="35" bgcolor="#FFffff"><div align="center"><?php echo $info['sprice'];?>元</div></td>
                  <td height="35" bgcolor="#FFffff"><div align="center"><?php echo @(ceil(($info['sprice']/$info['mprice'])*100))."%";?></div></td>
                  <td height="35" bgcolor="#FFffff"><div align="center"><?php echo $info['sprice']*$num."元";?></div></td>
                  <td height="35" bgcolor="#FFffff"><div align="center"><a href="removecart.php?id=<?php echo $info['id']?>">移除</a></div></td>
                </tr>
                <?php
			      }
				 }
			 ?>
                <tr bgcolor="#FFEDBF">
                  <td height="60" colspan="8" bgcolor="#FFffff"><div align="right">
                      <table width="500" height="60" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="125"><div align="center">
                              <input name="submit2" type="submit" class="tbutton" value="更改数量">
                          </div></td>
                          <td width="125"><div align="center"><a href="cart2.php"><input type="button" class="tbutton" value="去收银台"></a></div></td>
                          <td width="125"><div align="center"><a href="cart.php?qk=yes"><input type="button" class="tbutton" value="清空购物车"></a></div></td>
                          <td width="125"><div align="left">总计：<?php echo $total;?></div></td>
                        </tr>
                      </table>
                  </div></td>
                </tr>
                <?php
			 }}
			?>
            </table></td>
          </tr>
        </form>
    </table>
<br />
        </td>
      </tr>
    </table></td>
  </tr>
</table>
<script src="<?php echo __PUBLIC__;?>/js/jquery-1.8.0.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
	//加的效果
	$(".add").click(function(){
	var n=$(this).prev().val();
	var num=parseInt(n)+1;
	if(num==0){ return;}
	$(this).prev().val(num);
	});
	//减的效果
	$(".jian").click(function(){
	var n=$(this).next().val();
	var num=parseInt(n)-1;
	if(num==0){ return}
	$(this).next().val(num);
	});
	})
</script>
<?php
	include_once("footer.php");
?>