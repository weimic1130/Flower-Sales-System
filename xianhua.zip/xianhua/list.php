<?php 
	include_once("header.php");
	$page = $_REQUEST["page"]?$_REQUEST["page"]:"1";
	$whereSql = "";
	$page = $_REQUEST["page"]?$_REQUEST["page"]:"1";
	$list = db_get_page("select * from content1 where 1=1 $whereSql order by addtime desc", $page,12);
	if ($page*1>$list["page"]*1){
		$page = $list["page"];
	}
	$Page = new PageWeb($list["total"],$list["page_size"], "", $page);
	$page_show = $Page->show(); 
	$cat_title = "网站公告";
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("left.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"  class="sort"><a href="index.php">首页</a> &gt;&gt; <?php echo $cat_title;?></td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <?php
		foreach($list["data"] as $row) {
	?>
        <tr>
          <td width="584" height="30" align="left" class="line">&nbsp;&middot;&nbsp;<a href="mv.php?id=<?php echo $row['id'];?>"><?php echo $row['title'];?></a></td>
          <td width="180" height="30" align="right" class="line">&nbsp;<?php echo $row['addtime'];?></td>
        </tr>
        <?php } ?>
        <tr>
          <td height="20" colspan="2"> &nbsp;
              <table width="550" height="25" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center"><?php echo $page_show;?>
          </td>
        </tr>
      </table></td>
        </tr>
      </table>
        </td></tr>

    </table></td>
  </tr>
</table>
<?php 
	include_once("footer.php");
?>