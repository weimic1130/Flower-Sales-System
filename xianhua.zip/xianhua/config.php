﻿<?php
	//配置信息
	$CONFIG = array(
		'db_host'=>"127.0.0.1",	//数据库地址
		'db_name'=>"xianhua",//数据库名称
		'db_user'=>"root",		//数据库用户名
		'db_pass'=>"root",		//数据库密码
		'url'=>"http://localhost/xianhua",//网站根目录地址
		'webname'=>"鲜花网站的设计与实现",	//网站名称
	);
?>