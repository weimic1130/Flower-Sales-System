<?php 
	include_once("header.php");
	$whereSql = "1=1";
	$tb_name = "goods";
	if ($_REQUEST["categoryid"]){
		$whereSql .= " and categoryid=" . $_REQUEST["categoryid"];
	}
	if ($_REQUEST["keywords"]) {
		$whereSql .= " and title like '%". $_REQUEST["keywords"] ."%' ";
	}
	$page = $_REQUEST["page"]?$_REQUEST["page"]:"1";
	$list = db_get_page("select * from $tb_name where $whereSql and status=0 order by addtime desc", $page,9);
	if ($page*1>$list["page"]*1){
		$page = $list["page"];
	}
	$Page = new PageWeb($list["total"],$list["page_size"], "&categoryid=".$_REQUEST["categoryid"]."&keywords=".$_REQUEST["keywords"]."", $page);
	$page_show = $Page->show(); 
	if(!$_REQUEST["categoryid"]){$cat_title = "商品中心";}else{
	$catA = db_get_row("select * from category where id=".$_REQUEST["categoryid"]);
	$cat_title = $catA["title"];}
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("left.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"  class="sort"><a href="index.php">首页</a> &gt;&gt; <?php echo $cat_title;?></td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <?php
		foreach($list["data"] as $row) {
	?><div style="float:left; margin:5px; width:225px;"><table width="220" height="89" border="0" cellpadding="0" cellspacing="0" style="border:#CCC 1px solid; margin:10px;">
							<tr>
								<td align="center" valign="middle">
                                <a href="goodshow.php?id=<?php echo $row['id'];?>&categoryid=<?php echo $row['categoryid'];?>"><?php
						if (!$row["img"]){
					?>
						<img src="<?php echo __PUBLIC__;?>/images/avatar.png" width="217"  height="217"/>
					<?php }else{ ?>
						<img src="<?php echo __PUBLIC__;?>/Upload/<?php echo $row["img"];?>" width="217"  height="217" />
					<?php } ?></a>
							</td>
                            <tr><td height="30" align="center"><?php echo $row['title'];?></td></tr>
                            <tr><td height="30" align="center">价格:<span style="color:#e60432"><?php echo $row['sprice'];?></span>元  <a href="addcart.php?id=<?php echo $row['id'];?>"><img src="<?php echo __PUBLIC__;?>/images/cart-icon.png"  height="30" width="30"  align="absmiddle"/></a></td></tr>
			</table></div><?php
                }
			?>
        </td></tr>
        <tr>
          <td height="20" colspan="2"> &nbsp;
              <table width="550" height="25" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center"><?php echo $page_show;?>
          </td>
        </tr>
      </table>
        </td></tr>

    </table></td>
  </tr>
</table>
<?php 
	include_once("footer.php");
?>