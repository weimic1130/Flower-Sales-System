<?php
include_once("header.php");
check_loginuser();
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("userleft.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31" class="sort"><a href="index.php">首页</a> &gt;&gt; 我的订单</td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <?php
	      $page = $_REQUEST["page"]?$_REQUEST["page"]:1;
			$list = db_get_page("select * from orders where userid='".$_SESSION["id"]."' order by id desc", $page,5);
			if ($page*1>$list["page"]*1){
				$page = $list["page"];
			}
			$Page = new PageWeb($list["total"],$list["page_size"], "", $page);
			$page_show = $Page->show(); 
			foreach($list["data"] as $info) {
	  ?>
  <table cellpadding="0" cellspacing="0" width="99%"
  style="margin-top:20px;">
    <tr class="nav1">
      <td width="243" height="32" class="">&nbsp;&nbsp;订单号：<a href="ordershow.php?id=<?php echo $info['id'];?>"><?php echo $info['onumber'];?></a></td><td width="115" class="">金额总计：<?php echo $info['total'];?></td>
      <td width="200" class="">订单状态：<?php if($info['th']==0){ echo $info['zt'];?> <?php if($info['zt']=="未付款"){?><a href="ordersave.php?act=del&ordersid=<?php echo $info['id'];?> ">取消</a> <a href="ordersave.php?act=zhifu&ordersid=<?php echo $info['id'];?>"><font color="#FF0000">付款</font></a><?php }}elseif($info['th']==-1){echo "退货审核中";}else{echo "已退货";}?></td>
    </tr>
  </table><br />
  
  <?php $ordersta = db_get_all("select * from ordersta where ordersid=".$info['id']." order by id desc");foreach($ordersta as $ordersrow) {
	  $info1=db_get_row("select * from goods where id=".$ordersrow['goodid']);//调出商品信息
?>
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td class="tb2_td1">件数：<?php echo $ordersrow['nums'];?></td>
      <td class="tb2_td2"><a href="goodshow.php?id=<?php echo $info1['id'];?>&categoryid=<?php echo $info1['categoryid'];?>" target="_blank"><img src="<?php echo __PUBLIC__;?>/Upload/<?php echo $info1["img"];?>" width="100" height="100"/></a></td>
      <td class="tb2_td3"><a href="goodshow.php?id=<?php echo $info1['id'];?>&categoryid=<?php echo $info1['categoryid'];?>" target="_blank"><?php echo $info1['title'];?></a></td>
      <td class="tb1_td5">单价：<?php echo $ordersrow['price'];?></td>
      
      <td class="tb1_td7"><a href="addcart.php?id=<?php echo $info1['id']?>">再次购买</a></td>
    </tr>
  </table><br />
  <?php
	}
	}?>

        </td>
      </tr>
    </table>
    <table width="550" height="25" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center"><?php echo $page_show;?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<?php
	include_once("footer.php");
?>