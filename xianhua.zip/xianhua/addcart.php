<?php
include_once("common/init.php");
if($_POST['id']){$id = !empty($_POST['id']) ? intval($_POST['id']) : '0';}else{$id = !empty($_REQUEST['id']) ? intval($_REQUEST['id']) : '0';}//对传递参数判断，没有为0
$sums = !empty($_POST['sums']) ? intval($_POST['sums']) : '1';//数量 如果没有为1
$info = db_get_row("select * from goods where id=".$_REQUEST["id"]);//查询数据库里商品信息
if($info['amount']<$sums){//判断商品数量
	goBakMsg("该商品数量不够，请重新选择!");
	exit;
}
$array=explode("@",$_SESSION['producelist']);//分割购物车session
for($i=0;$i<count($array)-1;$i++){//循环判断是否存在当前商品
	if($array[$i]==$id){
		goBakMsg("该商品已经在您的购物车中!");
		exit;
	}
}
$_SESSION['producelist']=$_SESSION['producelist'].$id."@";//商品的id用@隔开并连接
$_SESSION['quatity']=$_SESSION['quatity']."".$sums."@";//商品的数量用@隔开并连接
header("location:cart.php");
?>