<?php 
	include_once("header.php");
	$row1 = db_get_row("select * from about where id=".$_REQUEST["id"]);
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("left.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"  class="sort"><a href="index.php">首页</a> &gt;&gt;<?php echo $row1["title"];?></td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <?php echo $row1["content"];?>
        </td>
      </tr>
    </table></td>
  </tr>
</table>

<?php
	include_once("footer.php");
?>