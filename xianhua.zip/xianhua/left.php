<table width="240" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebottom">
          <tr>
            <td height="32" align="center" class="leftcss">商品分类</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#FFFFFF" style="padding:10px 0px;">
        <table width="220"  border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td height="5"></td></tr>
			<?php $cateart = db_get_all("select * from category where pid=1 order by id desc limit 10");foreach($cateart as $caterow) {?>
          	<tr><td height="35" class="proOne"><a href="goods.php?categoryid=<?php echo $caterow["id"];?>"><?php echo $caterow['title'];?></a></td></tr>
			<?php }?>
        </table>
	</td>
</tr>
</table>
<table width="240" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebottom">
          <tr>
            <td height="32" align="center" class="leftcss">推荐商品</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#FFFFFF" style="padding:10px 0px;">
        <table width="220"  border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td height="5" colspan="2"></td></tr>
			<?php $goodt = db_get_all("select * from goods where isnice=1 order by id desc limit 10");foreach($goodt as $goodtrow) {?>
          	<tr><td width="15" height="30"><img src="<?php echo __PUBLIC__;?>/images/xing.gif" /></td>
          	  <td><a href="goodshow.php?categoryid=<?php echo $goodtrow["categoryid"];?>&id=<?php echo $goodtrow["id"];?>"><?php echo $goodtrow['title'];?></a></td>
          	</tr>
			<?php }?>
        </table>
	</td>
</tr>
</table>
