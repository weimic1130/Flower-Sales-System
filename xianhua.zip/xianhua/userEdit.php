<?php 
	include_once("common/init.php");
	check_loginuser();
	//echo $_SESSION["id"];
	//die;
	$row = db_get_row("select * from user where id=".$_SESSION["id"]);
	if ($_POST){
		$data = array();
		$data["nickname"] = "'".$_POST["nickname"]."'";
		$data["sex"] = "'".$_POST["sex"]."'";	
		$data["email"] = "'".$_POST["email"]."'";	
		$data["address"] = "'".$_POST["address"]."'";	
		$data["tel"] = "'".$_POST["tel"]."'";	
		if(!empty($_FILES['img']['name'])){
			$file = $_FILES['img'];//得到传输的数据
			//得到文件名称
			$name = $file['name'];
			$type = strtolower(substr($name,strrpos($name,'.')+1)); //得到文件类型，并且都转化成小写
			$allow_type = array('jpg','jpeg','gif','png'); //定义允许上传的类型
			//判断文件类型是否被允许上传
			if(!in_array($type, $allow_type)){
			  //如果不被允许，则直接停止程序运行
			}
			//判断是否是通过HTTP POST上传的
			$upload_path = ROOT_PATH.'/Public/Upload/'; //上传文件的存放路径
			
			//开始移动文件到相应的文件夹
			$mu=mt_rand(1,10000000);
			if(move_uploaded_file($file['tmp_name'],$upload_path.$mu.".".$type)){
			  $fileName =$mu.".".$type;
			}else{
			  //echo "Failed!";
			}
			$data["img"] = "'".$fileName."'";	
		}	

		db_mdf("user",$data,$_SESSION["id"]);
		urlMsg("修改成功", __BASE__."/userEdit.php");
	}
	include_once("header.php");
?>
<script type="text/javascript"> 
function check(){   
    if(document.form1.account.value==""){
		alert("请输入用户名");
		document.form1.account.focus();
		return false;}
	if(document.form1.email.value==""){
		alert("请输入电子邮箱");
		document.form1.email.focus();
		return false;}
	if(document.form1.nickname.value==""){
		alert("请输入姓名");
		document.form1.nickname.focus();
		return false;}
	
}
</script>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:10px;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("userleft.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"  class="sort"><a href="index.php">首页</a> &gt;&gt;个人中心</td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <table cellspacing=0 cellpadding=0 width="100%" align=center border=0>
  
    <tr>
      <td class=b valign=top align=left>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
         <tr>
          <td align="center"><p><font color="#ff3300" style="font-size:14px;"><b>个人资料更改</b></font></p>
         <form name="form1" method="post" action="?" onSubmit="return check();" enctype="multipart/form-data">
            <table width="98%" border="0" cellpadding="5" cellspacing="1"  align="center">
              <tr>
                <td height=15></td>
              </tr>
              <tr>
                <td width=35% height="35" align=right>用户名：</td>
                <td width=65% align="left"><input class="wenbenkuang" name="account" type="text" id="account" maxlength="18" value="<?php echo $row["account"];?>" readonly="readonly"><font color=red>*</font></td>
              </tr>
              <tr>
                <td width=35% height="35" align=right>电子邮箱：</td>
                <td align="left"><input class="wenbenkuang" name="email" type="text" value="<?php echo $row["email"];?>"><font color=red>*</font></td>
              </tr>
              
              <tr>
                <td width=35% height="35" align=right>姓名：</td>
                <td align="left"><input class="wenbenkuang" name="nickname" type="text" size="10" value="<?php echo $row["nickname"];?>"><font color=red>*</font> </td>
              </tr>
              <tr>
                <td width=35% height="35" align=right>性别：</td>
                <td align="left">
                	<select name="sex">
						<option value="未知" <?php if($row["sex"]=="未知"){echo "selected";}?>>未知</option>
						<option value="男" <?php if($row["sex"]=="男"){echo "selected";}?>>男</option>
						<option value="女" <?php if($row["sex"]=="女"){echo "selected";}?>>女</option>
						</select></td>
              </tr>
              
              <tr>
                <td width=35% height="35" align=right>联系电话：</td>
                <td align="left"><input class="wenbenkuang" name="tel" maxlength="18" type="text" value="<?php echo $row["tel"];?>"><font color=red>*</font></td>
              </tr>
              <tr>
                <td width=35% height="35" align=right>地址：</td>
                <td align="left"><input class="wenbenkuang" name="address" maxlength="50" type="text" value="<?php echo $row["address"];?>"></td>
              </tr>
              <tr>
                <td width=35% height="45" align=right>上传头像：</td>
                <td align="left"><input type="file" name="img" class="wenbenkuang" id="img"><?php if(!empty($row['img'])){?><img src="<?php echo __PUBLIC__;?>/Upload/<?php echo $row["img"];?>" height="50" width="50"/><?php }?></td>
              </tr>
              <tr>
                <td width=35% height="45" align="right"></td>
                <td align="left"><input class="tbutton" type=submit name="submit" value=" 提交信息 ">
                    <input class="tbutton"  name="clear" type="reset" value=" 重新填写 ">
                </td>
              </tr>
              <tr>
                <td height=15></td>
              </tr>
            </table>
        </form></td>
                </tr>
            </table>
       </td>
    </tr>
</table>
        </td>
      </tr>
    </table></td>
  </tr>
</table>
<?php
	include_once("footer.php");
?>