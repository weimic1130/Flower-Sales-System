<?php
	include_once("common/init.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $CONFIG["webname"];?></title>
<link href="<?php echo __PUBLIC__;?>/css/css.css" rel="stylesheet" type="text/css" />
<script src="<?php echo __PUBLIC__;?>/js/jquery-1.8.0.min.js"></script>
</head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td height="40" class="header-top-area" align="center">
    <table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr><td width="400">&nbsp;&nbsp;&nbsp;&nbsp;欢迎来到<?php echo $CONFIG["webname"];?></td>
    <td align="right"><a href="usercenter.php">个人中心</a>&nbsp;&nbsp;<a href="order.php">我的订单</a>&nbsp;&nbsp;<?php if ($_SESSION["account"]) {?><a href="userEdit.php">欢迎 <?php echo $_SESSION["account"];?></a>
	<?php }else {?>
	<a href="login.php">登录</a>&nbsp;&nbsp;<a href="register.php">注册</a><?php }?>
	&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
    </table>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td bgcolor="#FFFFFF" align="center">
  <table width="1000" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="110"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="473" align="left"><img src="<?php echo __PUBLIC__;?>/images/logo_head.jpg" width="400" height="80" /></td>
          <td width="527" align="center"><form action="goods.php" method="get">
					<table width="250" border="0" cellspacing="0" cellpadding="0" align="center">
                      <tr>
                        
                        <td width="220" align="center"><input style="height:30px; width:220px;" type="search" placeholder="请输入关键词" required  name="keywords" class="header-search"/></td>
                        <td width="30" align="center" class="searchback"><input type="submit" class="search_btn" value=""/></td>
                        
                      </tr>
                    </table>
				</form></td><td align="center"><a href="cart.php"><img src="<?php echo __PUBLIC__;?>/images/gouwuche.jpg" /></a></td>
          </tr>
      </table></td>
    </tr>
  </table>
  </td>
</tr>
</table>
    
   <div id="topnav">
        <div class="w">
            <ul>
                <li><a href="index.php">网站首页</a></li>
                <li><a href="goodst.php">推荐鲜花</a></li>
                <li ><a href="goods.php">全部鲜花</a>
                <?php $list1 = db_get_all("select * from category  where pid=1 order by id asc"); ?>
                <?php if($list1[0]){?>
                <dl>
                <?php foreach($list1 as $rowd) {?>
                <dt><a href="goods.php?categoryid=<?php echo $rowd["id"];?>"><?php echo $rowd["title"];?></a></dt>
                <?php }?>
                </dl>
                <?php }?>
                </li>
                <li ><a href="list.php">网站公告</a></li>
                <li ><a href="about.php?id=1">关于我们</a></li>
                <li ><a href="about.php?id=2">服务流程</a></li>
                <li ><a href="about.php?id=3">联系我们</a></li>
                <li ><a href="message.php">在线留言</a></li>
                
            </ul>
        </div>
    </div>
    <script>
	$(function(){
	$("#topnav li").hover(function(){
		cname=$(this).attr("class");
		if(!cname){$(this).addClass("hover");}
		$("dl",this).show();
	},function(){
		$("dl",this).hide();
		if(!cname){$(this).removeClass("hover");}
	});
	//
	DY_scroll('.pro_width','.arrow_left','.arrow_right','.pro_width',5,true);

})
</script>