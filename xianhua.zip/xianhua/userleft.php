<table width="240" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="tablebottom">
          <tr>
            <td width="130" height="32" align="center" class="leftcss">个人中心</td>
            <td></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#FFFFFF" style="padding:10px 0px;">
        <table width=100% border=0 align=center cellpadding=0 cellspacing=0>
        <tr>
        <td>
        <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
        <tr> 
        <td height="30" align="center"><a href="userEdit.php">个人资料</a></td>
        <td align="center"><a href="userEditp.php">修改密码</a></td>
        </tr>
         <tr>
          <td height="30" align="center"><a href="order.php">我的订单</a></td>
        <td align="center"><a href="login.php?type=logout">退出登录</a></td>
          </tr>
        </table>
        </td>
        </tr>
        </table>
	</td>
      </tr>
    </table>