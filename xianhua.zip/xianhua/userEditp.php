<?php 
	include_once("header.php");
	check_loginuser();
	if ($_POST){
		$row = db_get_row("select * from user where id=".$_SESSION["id"]);
		if($_POST["password"] != $_POST["repassword"]) {
			goBakMsg("两次密码输入不一致");
		} else if ($_POST["oldpassword"]!=$row["password"]) {
			goBakMsg("原密码错误");
		} else {
			$data = array();
			$data["password"] = "'".$_POST["password"]."'";
			db_mdf("user",$data,$_SESSION["id"]);
			goBakMsg("密码修改成功");
		}
		echo '<script> alert("'.$msg.'");</script>';
	}
?>
<script type="text/javascript"> 
function check(){
		if(document.form1.oldpassword.value==""){
		alert("请输入原密码");
		document.form1.oldpassword.focus();
		return false;
	}
	if(document.form1.password.value==""){
		alert("请输入密码");
		document.form1.password.focus();
		return false;
	}
	if(document.form1.repassword.value==""){
		alert("请输入确认密码");
		document.form1.repassword.focus();
		return false;
	}
	if(document.form1.password.value!=document.form1.repassword.value){
		alert("两次输入密码不一致");
		document.form1.repassword.focus();
		return false;
	}
}
</script>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:10px;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("userleft.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top" bgcolor="#FFFFFF">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"  class="sort"><a href="index.php">首页</a> &gt;&gt;个人中心</td>
      </tr>
      <tr>
        <td height="" valign="top" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <table cellspacing=0 cellpadding=0 width="100%" align=center border=0>
  
    <tr>
      <td class=b valign=top align=left>
        <div class="height10"></div><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                      <form name="form1" method="post" action="?" enctype="multipart/form-data" onSubmit="return check();">
                       <table width="98%" border="0" cellpadding="5" cellspacing="1"  align="center">
                          <tr>
                            <td height=15></td>
                          </tr>
                          <tr>
                            <td width=30% height="35" align=right>原密码：</td>
                            <td align="left" class=pad><input class="wenbenkuang" name="oldpassword" type="password" size="20" id="oldpassword" value="">
                                <font color=red>*</font></td>
                          </tr>
                          
                          <tr>
                            <td width=30% height="35" align=right>新密码：</td>
                            <td align="left" class=pad><input class="wenbenkuang" name="password" type="password" id="password" size="20"  value="">
                                <font color=red>*</font> </td>
                          </tr>
                          <tr>
                            <td width=30% height="35" align=right>确认密码：</td>
                            <td align="left" class=pad><input class="wenbenkuang" name="repassword" type="password" id="repassword" size="20"  value="">
                                <font color=red>*</font> </td>
                          </tr>
                          <tr>
                            <td width=20% height="45" align="right"></td>
                            <td align="left" class=pad><input class="tbutton" type=submit name="submit" value=" 提交信息 ">
                                <input class="tbutton"  type=reset name="clear" value=" 重新填写 ">
                            </td>
                          </tr>
                        </table>
                    </form></td>
                </tr>
            </table><div class="height10"></div></td>
          </tr>
        </table>
       
        </td>
        
      </tr>
    </table></td>
  </tr>
</table>
<?php
	include_once("footer.php");
?>