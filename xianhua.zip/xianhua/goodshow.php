<?php 
	include_once("header.php");
	$row = db_get_row("select * from goods where id=".$_REQUEST["id"]);
	db_query("update goods set apv=apv+1 where id=".$_REQUEST["id"]);
	if(!$_REQUEST["categoryid"]){$cat_title = "商品中心";}else{
	$catA = db_get_row("select * from category where id=".$_REQUEST["categoryid"]);
	$cat_title = $catA["title"];}
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31" class="sort"><a href="index.php">首页</a> &gt;&gt; <?php echo $cat_title;?></td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td valign="top" width="229"><table width="98%" border="0" cellspacing="0" cellpadding="2">
                      <tr>
                        <td align="center"><table cellspacing=0 cellpadding=0 width=220 height=220 border=0>
                            <tbody>
                              <tr>
                                <td align=center>
                                <script src="<?php echo __PUBLIC__;?>/js/jquery-1.8.0.min.js"></script>
<script src="<?php echo __PUBLIC__;?>/js/jquery.etalage.min.js"></script>

<script type="text/javascript">
$(document).ready(function($){

	$('#example2').etalage({
		thumb_image_width: 300,
		thumb_image_height: 300,
		source_image_width: 900,
		source_image_height: 675,
		zoom_area_height: 500,
		magnifier_invert: false,
		hide_cursor: true,
		icon_offset: 15,
		speed: 400
	});

});
</script><div id="examples">
		<link type="text/css" rel="stylesheet" href="<?php echo __PUBLIC__;?>/css/example2.css">
	
		<ul id="example2">
			<li>
				<img class="etalage_thumb_image" src="<?php echo __PUBLIC__;?>/Upload/<?php echo $row["img"];?>" />
				<img class="etalage_source_image" src="<?php echo __PUBLIC__;?>/Upload/<?php echo $row["img"];?>" />
			</li>
		</ul>
	</div>
                                </td>
                              </tr>
                            </tbody>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="501" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="2">
                      <tr>
                        <td height="30" align="left">商品名称：<font color="#cb1c1d" size="3"><strong><?php echo $row["title"];?></strong></font></td>
                      </tr>
                       <tr>
                        <td height="30" align="left">商品编号：<?php echo $row["pnumber"];?></td>
                      </tr>
                      <tr>
                        <td align="left" >商品剩余：<?php echo $row["amount"];?>
                         </td>
                      </tr>
                    <tr><td align="left">&nbsp;市场价：<s>￥<?php echo $row["mprice"];?>元</s>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" >&nbsp;会员价：<font color="#FF0000">￥<?php echo $row["sprice"];?>元</font>
                         </td>
                      </tr>
                      <form action="addcart.php" method="post">
                      <input type="hidden" value="<?php echo $row["id"];?>" name="id" />
                      
                      <tr>
                        <td align="left" >
						<div class="gw_num" style="border: 1px solid #dbdbdb;width: 110px;line-height: 26px;overflow: hidden;">
                            <em class="jian">-</em>
                            <input type="text" name="sums" value="1" class="num" readonly="readonly"/>
                            <em class="add">+</em>
                        </div>
						
                         </td>
                      </tr>              
                    <tr>
                      <td height="50" align="left"><input type="image" src="<?php echo __PUBLIC__;?>/images/X17.png" /></td>
                    </tr></form>
                  </table></td>
                </tr>
                
              </table>
              <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
					<td height="35" class="sort" style="border-bottom:#ccc 1px solid">&nbsp;&nbsp;详细介绍
         		   </td>
			  </tr>
              <tr><td>
             <div style="margin:10px;"><?php echo $row["content"];?></div>
              </td></tr>
              </table>
              <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
					<td height="35" class="sort" style="border-bottom:#ccc 1px solid">&nbsp;&nbsp;评论内容
         		   </td>
			  </tr>
            <tr>
              <td width="74%" height="30">
        <table width="100%" border="0" cellpadding="6" cellspacing="1">
            <tr>
              <td width="74%" height="30">
        <?php
			$page = $_REQUEST["page"]?$_REQUEST["page"]:1;
			$list = db_get_page("select * from comment where goodid=".$row["id"]." order by id desc", $page,10);
			if ($page*1>$list["page"]*1){
				$page = $list["page"];
			}
			$Page = new PageWeb($list["total"],$list["page_size"], "&id=".$_REQUEST["id"]."&categoryid=".$_REQUEST["categoryid"], $page);
			$page_show = $Page->show();
			foreach($list["data"] as $row1) {
			?>
            <link href="<?php echo __PUBLIC__;?>/css/book.css" rel="stylesheet" type="text/css" />
            <div class="book">
                    <div class="face"><?php if (!db_get_val("user",$row1["userid"],"img")){?>
						<img src="<?php echo __PUBLIC__;?>/images/avatar.png" width="60"  height="60"/>
					<?php }else{ ?>
						<img src="<?php echo __PUBLIC__;?>/Upload/<?php echo db_get_val("user",$row1["userid"],"img");?>" width="60"  height="60" />
					<?php } ?></div>
                    <div class="text">
                        <div class="div">
                            <div class="icon"></div>
                            <div class="base"><span><?php echo $row1['addtime'];?></span><?php echo db_get_val("user",$row1["userid"],"account");?></div>
                            <div class="content"><?php echo $row1['content'];?></div>
                        </div>
                    </div>
                </div>
    <?php } ?><table width="100%" align="center">

                 <tr>
              <td align="center"><?php echo $page_show;?></td>
            </tr></table>
    </td>
        </tr>
      </table>
              
              <table width="100%" border="0" cellpadding="0" cellspacing="0">
				<form name="form1" method="post" action="comment.php" onSubmit="return chkinput(this)">
				<input type="hidden" name="goodid" value="<?php echo $row["id"];?>" />
                <input type="hidden" name="userid" value="<?php echo $_SESSION["id"];?>" />
             <tr>
					<td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
					<td height="35" class="sort" style="border-bottom:#ccc 1px solid">&nbsp;&nbsp;发表评论
         		   </td>
			  </tr></table></td>
         		   </tr>
            <tr>
              <td height="150"><table width="650" border="0" align="center" cellpadding="0" cellspacing="1">
                  <script language="javascript">
		    function chkinput(form)
			{
			   if(form.content.value=="")
			   {
			     alert("请输入评论内容!");
				 form.content.select();
				 return(false);
			   }
			   return(true);
			}
		  </script>
                  <tr>
                    <td width="120" height="125" bgcolor="#FFFFFF"><div align="center">发表评论：</div></td>
                    <td width="544" height="125" bgcolor="#FFFFFF"><div align="left">
                    <br>
                      <textarea name="content" cols="50" rows="10" class="wenbenkuang"></textarea>
                      </div></td>
                  </tr>
                  <tr>
                    <td width="120" height="50" bgcolor="#FFFFFF">&nbsp;</td>
                    <td width="544" height="50" bgcolor="#FFFFFF"><input name="submit2" type="submit" class="tbutton" value="发表"></td>
                  </tr>
              </table>
              
              </td>
            </tr></form>
        </table>
</td></tr></table>
        </td>
      </tr>
    </table></td>
  </tr>
</table>
<script type="text/javascript">
	$(document).ready(function(){
	//加的效果
	$(".add").click(function(){
	var n=$(this).prev().val();
	var num=parseInt(n)+1;
	if(num==0){ return;}
	$(this).prev().val(num);
	});
	//减的效果
	$(".jian").click(function(){
	var n=$(this).next().val();
	var num=parseInt(n)-1;
	if(num==0){ return}
	$(this).next().val(num);
	});
	})
</script>
<?php
	include_once("footer.php");
?>