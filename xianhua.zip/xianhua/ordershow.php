<?php
include_once("header.php");
check_loginuser();
?>
<?php
$info2=db_get_row("select * from orders where id=".$_GET['id']);//调出订单信息
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("userleft.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31" class="sort"><a href="index.php">首页</a> &gt;&gt; 我的订单</td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="306" bgcolor="#FFFFFF"><table width="700"  border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="35" align="center" bgcolor="#f1f1f1">订单号：<?php echo $info2['onumber'];?></td>
      </tr>
    </table>
      <table width="700" height="60" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td><table width="700" border="0" align="center" cellpadding="0" cellspacing="1">
              <tr class="leftcss">
                <td width="153" height="20" align="center">商品名称</td>
                <td width="80" align="center">市场价</td>
                <td width="80" align="center">会员价</td>
                <td width="80" align="center">数量</td>
                <td width="101" height="35" align="center">小计</td>
              </tr>
              <?php 
			  $total = 0;
			  $ordersta = db_get_all("select * from ordersta where ordersid=".$info2['id']." order by id desc");foreach($ordersta as $ordersrow) {
				  $info1=db_get_row("select * from goods where id=".$ordersrow['goodid']);//调出商品信息
				  ?>
              <tr bgcolor="#FFFFFF">
                <td height="30" align="center" bgcolor="#FFFFFF"><a href="goodshow.php?id=<?php echo $info1['id'];?>&categoryid=<?php echo $info1['categoryid'];?>" target="_blank"><?php echo $info1['title'];?></a></td>
                <td height="20" align="center"><?php echo $info1['mprice'];?></td>
                <td height="20" align="center"><?php echo $ordersrow['price'];?></td>
                <td height="20" align="center"><?php echo $ordersrow['nums'];?></td>
                <td height="20" align="center"><?php echo $ordersrow['price']*$ordersrow['nums'];?></td>
              </tr>
              <?php
			  $total = $total+$ordersrow['price']*$ordersrow['nums'];
	   }
	 ?>
              <tr bgcolor="#FFFFFF">
                <td height="30" colspan="5" align="center" bgcolor="#FFFFFF">
                  <span class="style5">总计费用:</span><?php echo $total;?></td>
              </tr>
          </table></td>
        </tr>
      </table><div class="height25"></div>
      <table width="700" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#cccccc">
        <tr bgcolor="#FFFFFF">
          <td width="100" height="30" align="right" bgcolor="#FFFFFF">&nbsp;下单人：</td>
          <td colspan="3">&nbsp;&nbsp;<?php echo $_SESSION['account'];?></td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td height="30" align="right" bgcolor="#FFFFFF">&nbsp;收货人：</td>
          <td height="20">&nbsp;&nbsp;<?php echo $info2['receiver'];?></td>
          <td height="20" align="right">性别：&nbsp;</td>
          <td height="20">&nbsp;&nbsp;<?php echo $info2['sex'];?></td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td height="30" align="right" bgcolor="#FFFFFF">&nbsp;收货人地址：</td>
          <td height="20" colspan="3">&nbsp;&nbsp;<?php echo $info2['address'];?></td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td height="30" align="right" bgcolor="#FFFFFF">&nbsp;E-mail:</td>
          <td height="20">&nbsp;&nbsp;<?php echo $info2['email'];?></td>
          <td height="20" align="right">支付方式：&nbsp;</td>
          <td height="20">&nbsp;&nbsp;<?php echo $info2['zfff'];?></td>
        </tr>

        <tr bgcolor="#FFFFFF">
          <td height="30" align="right" bgcolor="#FFFFFF">&nbsp;送货方式：</td>
          <td height="20" colspan="3">&nbsp;&nbsp;<?php echo $info2['shff'];?></td>
          </tr>
          <?php if($info2['kuaidi']){?>
      <tr bgcolor="#FFFFFF">
        <td height="30" align="right">快递信息：</td>
        <td height="25" colspan="3">&nbsp;&nbsp;<?php echo $info2['kuaidi'];?>-<?php echo $info2['knumber'];?></td>
      </tr>
      <?php }?>
          
        <tr bgcolor="#FFFFFF">
          <td height="40" colspan="4" align="center">订单状态：<?php echo $info2['zt'];?> <?php if($info2['zt']=="已发货" )
							{?>
                            <a href="ordersave.php?act=shouhuo&ordersid=<?php echo $info2['id']?>" class="details"><button type="button" class="tbutton">确认收货</button></a>
                            <?php }
					   ?>  &nbsp;&nbsp;<?php if($info2['zt']=="未付款")
							{?><a href="ordersave.php?act=zhifu&ordersid=<?php echo $info2['id']?>" class="details"><button type="button" class="tbutton">点击支付</button></a><?php } ?>
          </td>
        </tr>
        <tr bgcolor="#FFFFFF">
          <td height="30" colspan="4" align="center" bgcolor="#FFFFFF">
            创建时间：<?php echo $info2['addtime'];?></td>
          </tr>
          <tr>
                          <td align="center" bgcolor="#FFFFFF" colspan="4" height="30"><?php
					   		if($info2['zt']=="已收货"&&$info2['th']==0)
							{
					   ?><a href="ordersave.php?act=tuihuo&ordersid=<?php echo $info2['id']?>"><button type="button" class="tbutton">我要退货</button></a>
                        <?php
							}
							if($info2['zt']=="已收货"&&$info2['th']==-1)
							{
					   ?>退货处理中
                        <?php
							}
							elseif($info2['zt']=="已收货"&&$info2['th']==1){echo "已退货";}
					   ?>
                        </td>
                       </tr>
      </table>
<?php
$_SESSION['producelist']="";
$_SESSION['quatity']=""; 
?></td>
  </tr>
</table>

        </td>
      </tr>
    </table></td>
  </tr>
</table>
<?php
	include_once("footer.php");
?>

