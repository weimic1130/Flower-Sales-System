<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="10"></td></tr></table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="footer" align="center">
  <tr>
  <td height="150">
  <table width="100%" height="75" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="75" align="center"><table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="20" align="center">系统名称： <?php echo $CONFIG["webname"];?></td>
          </tr>
          <tr>
            <td height="23" align="center">电话： 000-000000000</td>
          </tr>
        </table></td>
      </tr>
    </table>
  </td></tr></table>
  </body>
 </html>