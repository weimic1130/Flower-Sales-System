<?php 
	include_once("common/init.php");

	if($_REQUEST["type"]=="logout"){//退出登录,清空session
		session_destroy();
		session_start();
		urlMsg("退出成功", __BASE__."/login.php");
		die;
	}
	if ($_POST) {
			$rsRow = db_get_row("select * from user where account='". $_POST["account"] ."'");//判断是否有这个用户名
			if ($rsRow['password'] == $_POST["password"]){//判断密码是否正确
				$_SESSION["id"]=$rsRow['id'];//赋值session
				$_SESSION['account']=$rsRow['account'];
				$_SESSION['nickname']=$rsRow['nickname'];
				urlMsg("登录成功", __BASE__."/usercenter.php");
				die;
			} else {
				goBakMsg("账号不存在或密码错误");
			}
	}
include_once("header.php");

?>
<script type="text/javascript"> 
function check(){   
    if(document.form1.account.value==""){
		alert("请输入用户名");
		document.form1.account.focus();
		return false;}
	if(document.form1.password.value==""){
		alert("请输入密码");
		document.form1.password.focus();
		return false;
	}
	
}
</script>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:10px;">
  <tr>
    <td width="1000" valign="top" bgcolor="#FFFFFF">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"><table width="100%" height="30" border="0" cellpadding="0" cellspacing="0" class="nav1">
            <tr>
              <td align="left" class="con2">&nbsp;&nbsp;&nbsp;用户登录</td>
              <td width="59" align="center" valign="middle"></td>
            </tr>
          </table></td>
      </tr>
      <tr>
        <td height="" valign="top" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <form name="form1" method="post" action="?" onSubmit="return check();">
            <table width="98%" border="0" cellpadding="5" cellspacing="1"  align="center">
              <tr>
                <td height=15></td>
              </tr>
              <tr>
                <td width=39% height="35" align=right><span id="usercheck" style="color:red;"></span>用户名：</td>
                <td width=61% align="left"><input class="wenbenkuang" name="account" type="text" id="account" maxlength="18"><font color=red>*</font></td>
              </tr>
              <tr>
                <td width=39% height="35" align=right>密码：</td>
                <td align="left"><input class="wenbenkuang" name="password" type="password" id="password" maxlength="18"><font color=red>*</font></td>
              </tr>
              <tr>
                <td width=39% height="45" align="right"></td>
                <td align="left"><input class="tbutton" type=submit name="submit" value=" 提交信息 ">
                  <input class="tbutton"  name="clear" type="reset" value=" 重新填写 ">
                  </td>
              </tr>
              <tr>
                <td height=15></td>
              </tr>
            </table>
        </form>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
<?php
include_once("footer.php");
?>