<?php 
	include_once("header.php");
	if ($_POST){
		$row = db_get_row("select * from user where account='". $_POST["account"] ."'");//查询用户名是否重复
		if ($row["id"]) {
			goBakMsg("用户名已存在");
			die;
		}
		//提交的数据放入数组,调用db_add添加到数据库
		$data = array();
		$data["account"] = "'". $_POST["account"] ."'";
		$data["nickname"] = "'". $_POST["nickname"] ."'";
		$data["email"] = "'". $_POST["email"] ."'";
		$data["sex"] = "'". $_POST["sex"] ."'";
		$data["tel"] = "'". $_POST["tel"] ."'";
		$data["password"] = "'". $_POST["password"] ."'";
		$data["address"] = "'".$_POST["address"]."'";
		db_add("user", $data);
		urlMsg("注册成功", __BASE__."/login.php");
		die;
	}
?>
<script type="text/javascript"> 
function check(){   
    if(document.form1.account.value==""){
		alert("请输入用户名");
		document.form1.account.focus();
		return false;}
	if(document.form1.password.value==""){
		alert("请输入密码");
		document.form1.password.focus();
		return false;
	}
	if(document.form1.password1.value==""){
		alert("请输入确认密码");
		document.form1.password1.focus();
		return false;
	}
	if(document.form1.password.value!=document.form1.password1.value){
		alert("两次输入密码不一致");
		document.form1.password1.focus();
		return false;
	}
	if(document.form1.email.value==""){
		alert("请输入电子邮箱");
		document.form1.email.focus();
		return false;}
	if(document.form1.nickname.value==""){
		alert("姓名为必填");
		document.form1.nickname.focus();
		return false;}
	if(document.form1.tel.value==""){
		alert("电话为必填");
		document.form1.tel.focus();
		return false;}
	
}
</script>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:10px;">
  <tr>
    <td width="1000" valign="top" bgcolor="#FFFFFF">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"><table width="100%" height="30" border="0" cellpadding="0" cellspacing="0" class="nav1">
            <tr>
              <td align="left" class="con2">&nbsp;&nbsp;&nbsp;用户注册</td>
              <td width="59" align="center" valign="middle"></td>
            </tr>
          </table></td>
      </tr>
      <tr>
        <td height="" valign="top" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <form name="form1" method="post" action="?" onSubmit="return check();">
            <table width="98%" border="0" cellpadding="5" cellspacing="1"  align="center">
              <tr>
                <td height=15></td>
              </tr>
              <tr>
                <td width=39% height="35" align=right>用户名：</td>
                <td width=61% align="left"><input class="wenbenkuang" name="account" type="text" id="account" maxlength="18"><font color=red>*</font></td>
              </tr>
              <tr>
                <td width=39% height="35" align=right>密码：</td>
                <td align="left"><input class="wenbenkuang" name="password" type="password" id="password" maxlength="18"><font color=red>*</font></td>
              </tr>
              <tr>
                <td width=39% height="35" align=right>确认密码：</td>
                <td align="left"><input class="wenbenkuang" name="password1" type="password" id="password1" maxlength="18">
                    <font color=red>*</font></td>
              </tr>
              <tr>
                <td width=39% height="35" align=right>电子邮箱：</td>
                <td align="left"><input class="wenbenkuang" name="email" type="text" id="email"><font color=red>*</font></td>
              </tr>
              
              <tr>
                <td width=39% height="35" align=right>姓名：</td>
                <td align="left"><input class="wenbenkuang" name="nickname" type="text" id="nickname" size="10"><font color=red>*</font> </td>
              </tr>
              <tr>
                <td width=39% height="35" align=right>性别：</td>
                <td align="left"><input type="radio" name="sex" id="select1" value="男" checked>
                  男
                    <input type="radio" name="sex" id="select1" value="女">
                    女 </td>
              </tr>
              
              <tr>
                <td width=39% height="35" align=right>联系电话：</td>
                <td align="left"><input class="wenbenkuang" name="tel" maxlength="18" type="text" id="tel"><font color=red>*</font></td>
              </tr>
              <tr>
                <td width=39% height="35" align=right>地址：</td>
                <td align="left"><input class="wenbenkuang" name="address" maxlength="50" type="text" id="address"></td>
              </tr>
              <tr>
                <td width=39% height="45" align="right"></td>
                <td align="left"><input class="tbutton" type=submit name="submit" value=" 提交信息 ">
                    <input class="tbutton"  name="clear" type="reset" value=" 重新填写 ">
                </td>
              </tr>
              <tr>
                <td height=15></td>
              </tr>
            </table>
        </form>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
<div class="height10"></div>
<?php
include_once("footer.php");
?>