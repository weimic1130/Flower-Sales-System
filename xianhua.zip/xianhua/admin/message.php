<?php 
	include_once("../common/init.php");
	check_login();
	$page = $_REQUEST["page"]?$_REQUEST["page"]:1;
	$list = db_get_page("select * from message order by id desc", $page,6);
	if ($page*1>$list["page"]*1){
		$page = $list["page"];
	}
	$Page = new PageWeb($list["total"],$list["page_size"], "", $page);
	$page_show = $Page->show(); 
?>
<?php include_once("base.php");?>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr class="topplace">
		<td width="17" rowspan="2" valign="top"></td>
		<td valign="top">
			<table width="100%" height="31" border="0" cellpadding="0" cellspacing="0">
				<tr><td height="31"><div class="title">留言列表</div></td></tr>
			</table>
		</td>
		<td width="16" rowspan="2"></td>
	</tr>
	<tr>
	<td valign="top" bgcolor="#F7F8F9">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td colspan="4" height="10"></td></tr>
            <tr><td width="1%">&nbsp;</td><td width="96%">
            </td><td width="1%">&nbsp;</td></tr>
			<tr>
				<td width="1%">&nbsp;</td>
				<td width="96%">
					<table width="100%">
						<td colspan="2">
							<?php
									foreach($list["data"] as $row) {
								?><table width="100%"  class="cont tr_color">
                            
								<tr>
									<th width="33%" align="left"><div style="color:#666; font-weight:100;">&nbsp;&nbsp;&nbsp;&nbsp;<?php echo db_get_val("user",$row["userid"],"account")?> 发表于：<?php echo $row['addtime'];?></div></th>
									<th width="67%" align="right"><a href="message_reply.php?id=<?php echo $row['id'];?>">回复</a>&nbsp;&nbsp;&nbsp;<a href="del.php?id=<?php echo $row["id"]; ?>&del=message" onclick='return confirm("真的要删除?不可恢复!");'>删除</a>&nbsp;&nbsp;</th>
                                </tr>
                                
								<tr align="center" class="d">
									<td colspan="2" align="left"><div style="margin:10px;"><?php echo $row['content'];?>
									<?php 
										if($row['recontent']){?>
                                        <hr  style="margin-top:8px; color:#ccc"/>
                                        <?php
											echo '<br>我的回复：'.$row["recontent"].'&nbsp;时间：'.$row["retime"].'';
										}
									?></div></td>
                                </tr>
							</table> <br /><?php } ?>
						</td>
					</tr>
					</table>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
                        <tr>
                          <td align="center"><?php echo $page_show;?></td>
                        </tr>
                      </table>    
					</td>
					<td width="1%">&nbsp;</td>
				</tr>
				<tr><td height="20"></td></tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>