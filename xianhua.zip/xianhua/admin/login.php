<?php 
	include_once("../common/init.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<head id="Head1"><title><?php echo $CONFIG["webname"];?>-登录</title>
    <style type="text/css">
        *
        {
            margin: 0px;
            padding: 0px;
        }
        body
        {
            background-color: #d5e1f0;
            margin-top: 50px;
        }
        .login
        {
            width: 300px;
            font-family: "宋体" , "黑体" , "新宋体";
            font-size: 12px;
            color: #494949;
            line-height: 2.2em;
            padding-top: 60px;
            padding-left: 145px;
        }
        .main
        {
            width: 850px;
            margin-right: auto;
            margin-left: auto;
        }
        .img1
        {
            background-image: url(skin/login/images/img_login1.gif);
            background-repeat: no-repeat;
            height: 120px;
        }
        .img2
        {
            background-image: url(skin/login/images/img_login2.gif);
            background-repeat: no-repeat;
            height: 100px;
        }
        .img3
        {
            background-image: url(skin/login/images/img_login3.gif);
            background-repeat: no-repeat;
            height: 214px;
        }
        .img4
        {
            background-image: url(skin/login/images/img_login4.gif);
            background-repeat: no-repeat;
            height: 200px;
        }
        input
        {
            background-color: #FFFFFF;
            font-size: 12px;
            color: #666666;
            padding: 2px;
            border: 1px solid #A3C1EC;
            float: left;
            margin-right: 6px;
            margin-top: 3px;
        }
        .button
        {
            border: 1px solid #779dd4;
            padding: 2px 10px; *padding-top:5px!important;background-image:url(skin/login/images/btn1.gif);background-repeat:repeat-x;line-height:20px;*line-height:10px!important;color:#779DD4;}
        .button_hover
        {
            border: 1px solid #b0c6e6;
            background-image: url(skin/login/images/btn2.gif);
            background-repeat: repeat-x;
            padding-top: 3px; *padding-top:6px!important;padding-right:9px;padding-bottom:1px;padding-left:11px;line-height:20px;*line-height:10px!important;}
        a.button, a.button_hover
        {
            border: 1px solid #b0c6e6;
            background-image: url(skin/login/images/btn2.gif);
            background-repeat: repeat-x;
            padding-top: 3px; *padding-top:6px!important;padding-right:9px;padding-bottom:1px;padding-left:11px;line-height:20px;*line-height:10px!important;}
            
          a
          {
          text-decoration:none;
          color:Green;
          
          }
            </style>
            
</head>
<body>
   
    <div class="img1 main">
    </div>
    <div class="img2 main">
    </div>
    <div class="img3 main">
        <div class="login"> <form name="form1" method="post" action="logincheck.php" id="form1">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
             <tr>
                    <td align="left" colspan="2" >
                    <div style="width:280px;height:20px;border:solid 0px red;overflow:hidden;">
                       <span id="Message" style="color:Red;"></span> &nbsp; </div>
                    </td>
                </tr>
                <tr>
                    <td width="60px" align="right">
                        登录账号：
                    </td>
                    <td>
                       <input name="account" type="text" maxlength="50" id="account"  required="required"/>
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        密码：
                    </td>
                    <td>
                        
                        <input id="password" type="password" name="password"  value=""  maxlength="50"  required="required"/>
                    </td>
                </tr>
               
                <tr>
                    <td height="35">&nbsp;
                         
                    </td>
                    <td>
                      <div style="width:5px; border:solid 0px red;float:left;" ></div>   
                       
                       <div style="width:100px;border:solid 0px red;" >
                         <input type="submit" name="LoginBtn" value="登录" id="LoginBtn" class="button" onmouseover="this.className='button_hover'" onmouseout="this.className='button'" style="width:66px;" /></div>
                       
                    </td>
                </tr>
            </table>  </form>
        </div>
    </div>
    <div class="img4 main">
    </div>
</body>
</html>
