<?php 
	include_once("../common/init.php");
	check_login();
	$page = $_REQUEST["page"]?$_REQUEST["page"]:1;
	$list = db_get_page("select * from comment where goodid=".$_REQUEST["goodid"]." order by id desc", $page,10);
	if ($page*1>$list["page"]*1){
		$page = $list["page"];
	}
	$Page = new PageWeb($list["total"],$list["page_size"], "", $page);
	$page_show = $Page->show(); 
?>
<?php include_once("base.php");?>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="17" rowspan="2" valign="top" bgcolor="#FFFFFF"></td>
		<td valign="top">
			<table width="100%" height="31" border="0" cellpadding="0" cellspacing="0">
				<tr bgcolor="#FFFFFF"><td height="31"><div class="title">评论列表</div></td></tr>
			</table>
		</td>
		<td width="16" rowspan="2" bgcolor="#FFFFFF"></td>
	</tr>
	<tr>
	<td valign="top" bgcolor="#F7F8F9">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr><td colspan="4" height="10"></td></tr>
			<tr>
				<td width="1%">&nbsp;</td>
				<td width="96%">
					<table width="100%">
						<td colspan="2">
                        	<?php
									foreach($list["data"] as $row) {
								?>
							<table width="100%"  class="cont tr_color">
								<tr>
									<th align="left">&nbsp;&nbsp;评论人:<?php echo db_get_val("user",$row["userid"],"account")?>&nbsp;&nbsp;评论商品:<?php echo db_get_val("goods",$row["goodid"],"title")?>&nbsp;&nbsp;评论时间:<?php echo $row["addtime"];?></th><th>操作</th>
                                </tr>
								<tr align="center" class="d">
									<td align="left">&nbsp;&nbsp;<?php echo $row["content"];?></td>
                                    <td><a href="del.php?id=<?php echo $row['id'];?>&del=comment" onclick='return confirm("真的要删除?不可恢复!");'>删除</a></td>
                                </tr>
                               
							</table>
                             <?php } ?>
						</td>
					</tr>
					</table>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
                        <tr>
                          <td align="center"><?php echo $page_show;?></td>
                        </tr>
                      </table>    
					</td>
					<td width="1%">&nbsp;</td>
				</tr>
				<tr><td height="20"></td></tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>