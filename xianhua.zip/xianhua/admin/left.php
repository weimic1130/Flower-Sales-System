<?php 
	include_once("../common/init.php");
	check_login();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=8" >
<title>左边导航</title>
<link rel="stylesheet" type="text/css" href="skin/index/css/reset.css"/>
<link rel="stylesheet" type="text/css" href="skin/index/css/common.css"/>
<script type="text/javascript" src="skin/index/js/jquery-1.8.3.min.js"></script>
<!--框架高度设置-->
<script type="text/javascript">
$(function(){
	$('.sidenav li').click(function(){
		$(this).siblings('li').removeClass('now');
		$(this).addClass('now');
	});
	
	$('.erji li').click(function(){
		$(this).siblings('li').removeClass('now_li');
		$(this).addClass('now_li');
	});
	
	var main_h = $(window).height();
	$('.sidenav').css('height',main_h+'px');
})
</script>
<!--框架高度设置-->
</head>

<body>
<div id="left_ctn">
    <ul class="sidenav">
        <li class="now">
            <div class="nav_m"><span><a>系统设置</a></span><i>&nbsp;</i></div>
            <ul class="erji">
                <li class="now_li"><span><a href="password.php" target="main">修改密码</a></span></li>
                <?php if($_SESSION['type2']=="超级管理员"){?>
				<li><span><a href='admin_list.php' target='main'>账号管理</a></span></li>
				<li><span><a href='admin_edit.php' target='main'>添加账号</a></span></li>
                <?php }?>
            </ul>
        </li>
        <li><div class="nav_m"><span><a>公告管理</a></span><i>&nbsp;</i></div>
            <ul class="erji">
            	<li><span><a href='content1_edit.php?pid=2&categoryid=5' target='main'>添加信息</a></span></li>
                <li><span><a href='content1_list.php?pid=2&categoryid=5' target='main'>信息管理</a></span></li>
            </ul>
        </li>
        <li><div class="nav_m"><span><a>商品管理</a></span><i>&nbsp;</i></div>
            <ul class="erji">
            	<li><span><a href='goods_edit.php?pid=1' target='main'>添加商品</a></span></li>
                <li><span><a href='goods_list.php?pid=1' target='main'>商品管理</a></span></li>
                <li><span><a href='category_edit.php?pid=1' target='main'>添加商品分类</a></span></li>
                <li><span><a href='category_list.php?pid=1' target='main'>商品分类管理</a></span></li>
            </ul>
        </li>
        <li><div class="nav_m"><span><a>订单管理</a></span><i>&nbsp;</i></div>
            <ul class="erji">
            	<li><span><a href='order_list.php' target='main'>订单管理</a></span></li>
            </ul>
        </li>
        <li><div class="nav_m"><span><a>留言管理</a></span><i>&nbsp;</i></div>
            <ul class="erji">
            	<li><span><a href='message.php' target='main'>留言管理</a></span></li>
            </ul>
        </li>
        
        <li><div class="nav_m"><span><a>用户管理</a></span><i>&nbsp;</i></div>
            <ul class="erji">
            	<li><span><a href='user_list.php' target='main'>用户管理</a></span></li>
            </ul>
        </li>
        <li>
            <div class="nav_m">
                <span><a href="logincheck.php?type=logout" target="_top">退出系统</a></span>
            </div>
        </li>
    </ul>
</div>
</body>
</html>