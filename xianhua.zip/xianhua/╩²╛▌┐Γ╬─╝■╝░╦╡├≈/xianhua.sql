/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : a145xianhua

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2018-09-29 18:07:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `about`
-- ----------------------------
DROP TABLE IF EXISTS `about`;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of about
-- ----------------------------
INSERT INTO `about` VALUES ('1', '关于我们', '关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们');
INSERT INTO `about` VALUES ('2', '服务流程', '服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程服务流程');
INSERT INTO `about` VALUES ('3', '联系我们', '联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们联系我们');

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'admin', 'admin', '超级管理员');
INSERT INTO `admin` VALUES ('2', '111', '698d51a19d8a121ce581499d7b701668', '管理员');
INSERT INTO `admin` VALUES ('3', '1', '1', '管理员');

-- ----------------------------
-- Table structure for `category`
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(6) NOT NULL AUTO_INCREMENT COMMENT 'id自然编号',
  `pid` int(6) NOT NULL COMMENT '分类类型',
  `title` varchar(60) NOT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', '1', '友情鲜花3');
INSERT INTO `category` VALUES ('2', '1', '爱情鲜花');
INSERT INTO `category` VALUES ('3', '1', '生日鲜花');
INSERT INTO `category` VALUES ('4', '1', '求婚鲜花');
INSERT INTO `category` VALUES ('5', '2', '网站公告');
INSERT INTO `category` VALUES ('6', '1', '婚庆鲜花');

-- ----------------------------
-- Table structure for `comment`
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT '0' COMMENT '用户id',
  `goodid` int(11) DEFAULT '0' COMMENT '商品id',
  `content` varchar(250) DEFAULT NULL COMMENT '评论内容 ',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('2', '3', '11', '我来评论一下', '2018-09-28 20:44:03');
INSERT INTO `comment` VALUES ('3', '5', '12', '添加一条评价', '2018-09-28 20:44:03');
INSERT INTO `comment` VALUES ('4', '1', '17', '评论内容评论内容评论内容评论内容评论内容评论内容评论内容评论内容评论内容', '2018-09-28 20:44:03');
INSERT INTO `comment` VALUES ('5', '9', '13', '我来评论一下', '2018-09-28 20:44:03');
INSERT INTO `comment` VALUES ('6', '11', '16', '我来评论一下', '2018-09-28 20:44:03');
INSERT INTO `comment` VALUES ('7', '11', '19', '奇才', '2018-09-28 20:44:03');

-- ----------------------------
-- Table structure for `content1`
-- ----------------------------
DROP TABLE IF EXISTS `content1`;
CREATE TABLE `content1` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(4) NOT NULL DEFAULT '0' COMMENT '类型id',
  `categoryid` int(4) NOT NULL DEFAULT '0' COMMENT '分类id',
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '详细介绍',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `apv` int(4) NOT NULL DEFAULT '0' COMMENT '点击',
  `img` varchar(50) DEFAULT NULL COMMENT '图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of content1
-- ----------------------------
INSERT INTO `content1` VALUES ('1', '3', '5', '添加一要 ', '<p>添加一要 <br/>添加一要 <br/>添加一要 <br/>添加一要 <br/>添加一要 添加一要 <br/><br/></p>', '2018-09-28 20:44:03', '7', null);
INSERT INTO `content1` VALUES ('2', '2', '5', '测试', '<p>压顶地<br/></p>', '2018-09-28 20:44:03', '29', null);
INSERT INTO `content1` VALUES ('3', '2', '5', '添加一条测试', '<p>dfdfdsf<br/></p>', '2018-09-28 20:44:03', '7', null);
INSERT INTO `content1` VALUES ('4', '2', '5', '添加一条测试aaa', '<p>dsdfdfdfsdfdsf<br/></p>', '2018-09-28 20:44:03', '5', null);
INSERT INTO `content1` VALUES ('5', '2', '5', 'dfdfsdfdsf', '<p>sdfsdf<br/></p>', '2018-09-28 20:44:03', '8', null);
INSERT INTO `content1` VALUES ('6', '2', '5', '添加一条测试', '<p>添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试</p>', '2018-09-28 20:44:03', '5', null);
INSERT INTO `content1` VALUES ('7', '6', '5', '添加一条测试', '<p>添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试</p>', '2018-09-28 20:44:03', '0', '');
INSERT INTO `content1` VALUES ('24', '2', '5', '添加一条俟', '<p>添加一条俟添加一条俟添加一条俟添加一条俟添加一条俟</p>', '2018-09-28 20:44:03', '6', null);
INSERT INTO `content1` VALUES ('25', '2', '5', 'fddfdfsd', '<p>dsfsddf<br/></p>', '2018-09-28 20:44:03', '1', null);
INSERT INTO `content1` VALUES ('26', '2', '5', '添加一条测试', '<p>dsfdfdsf<br/></p>', '2018-09-28 20:44:03', '2', null);

-- ----------------------------
-- Table structure for `goods`
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(4) NOT NULL DEFAULT '0' COMMENT '类型id',
  `categoryid` int(4) NOT NULL DEFAULT '0' COMMENT '分类id',
  `pnumber` varchar(50) DEFAULT NULL COMMENT '商品号',
  `title` varchar(50) DEFAULT NULL COMMENT '名称',
  `amount` int(11) DEFAULT '0' COMMENT '商品数量',
  `cishu` int(11) DEFAULT '0',
  `mprice` decimal(11,0) DEFAULT NULL COMMENT '市场价',
  `sprice` decimal(11,0) DEFAULT NULL COMMENT '会员价',
  `content` text COMMENT '详细介绍',
  `apv` int(4) NOT NULL DEFAULT '0' COMMENT '点击',
  `img` varchar(50) DEFAULT NULL COMMENT '图片',
  `status` int(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isnice` int(2) NOT NULL DEFAULT '0' COMMENT '是否促销',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('10', '1', '2', 'dfdfd', '特级现货', '0', '4', '34', '343', '<p>dfdsff<br/></p>', '74', '6346043.jpg', '0', '2018-09-28 20:44:03', '1');
INSERT INTO `goods` VALUES ('11', '1', '2', 'dfdfd', '特级鲜花d', '30', '4', '34', '343', '<p>dfsdf<br/></p>', '74', '7949698.jpg', '0', '2018-09-28 20:44:03', '0');
INSERT INTO `goods` VALUES ('12', '1', '2', 'dfdfds3', '添加一条测试添加', '2', '1', '3400', '3000', '<p>34343<br/></p>', '16', '8003772.jpg', '0', '2018-09-28 20:44:03', '0');
INSERT INTO `goods` VALUES ('13', '1', '1', 'dfdfds3', '添加一条测试添加', '33', '0', '34', '22', '<p>添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试<img src=\"/ueditor/php/upload/image/20171114/1510663146606532.jpg\" title=\"1510663146606532.jpg\" alt=\"16pic_2630608_b.jpg\"/><br/></p>', '47', '5200031.jpg', '0', '2018-09-28 20:44:03', '1');
INSERT INTO `goods` VALUES ('14', '1', '4', 'dfdfds3', '添加一条测试添加', '33', '0', '34', '22', '<p>mysqld-nt.exemysqld-nt.exemysqld-nt.exemysqld-nt.exemysqld-nt.exe<br/></p>', '10', '5780848.jpg', '0', '2018-09-28 20:44:03', '1');
INSERT INTO `goods` VALUES ('15', '1', '2', 'dfdfds3', '添加一条测试添加', '33', '0', '258', '200', '<p>添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加', '9', '5424493.jpg', '0', '2018-09-28 20:44:03', '0');
INSERT INTO `goods` VALUES ('16', '1', '3', 'dfdfds31', '添加一条测试添加', '32', '1', '444', '333', '<p>添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加', '15', '7133872.jpg', '0', '2018-09-28 20:44:03', '0');
INSERT INTO `goods` VALUES ('17', '1', '4', 'ddfsdf22', '添加一条测试', '216', '6', '500', '480', '<p>添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试<br/></p>', '109', '5579424.jpg', '0', '2018-09-28 20:44:03', '1');
INSERT INTO `goods` VALUES ('19', '1', '2', 'dfdfds3ss', '添加一条测试', '31', '2', '258', '200', '<p>dsd添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试添加一条测试</p>', '45', '7855419.jpg', '0', '2018-09-28 20:44:03', '1');

-- ----------------------------
-- Table structure for `message`
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL,
  `content` varchar(200) NOT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `recontent` varchar(250) DEFAULT NULL,
  `isno` int(2) DEFAULT '0',
  `retime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('3', '1', '可以通过', '2018-09-27 10:44:03', null, '0', null);
INSERT INTO `message` VALUES ('4', '6', 'dfsdfdf', '2018-09-27 10:44:03', 'dfsdfdsf', '1', '2018-09-28 20:44:03');
INSERT INTO `message` VALUES ('5', '9', '我来留言来了', '2018-09-27 10:44:03', '我是管理', '1', '2018-09-28 20:44:03');
INSERT INTO `message` VALUES ('6', '11', '我来留言来了', '2018-09-27 10:44:03', '我来留言来了', '1', '2018-09-28 20:44:03');
INSERT INTO `message` VALUES ('7', '13', '留言！！！', '2018-09-29 18:04:01', '好', '1', '2018-09-29 18:04:36');

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `onumber` varchar(50) DEFAULT NULL COMMENT '订单号',
  `userid` int(11) DEFAULT '0' COMMENT '用户id',
  `spc` varchar(50) DEFAULT NULL COMMENT '订单商品',
  `slc` varchar(50) DEFAULT NULL COMMENT '订单商品数量',
  `sex` varchar(50) DEFAULT NULL COMMENT '性别',
  `address` varchar(50) DEFAULT NULL COMMENT '地址',
  `tel` varchar(50) DEFAULT NULL COMMENT '电话',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `shff` varchar(50) DEFAULT NULL COMMENT '收货方式',
  `zfff` varchar(50) DEFAULT NULL COMMENT '支付方式',
  `leaveword` varchar(100) DEFAULT NULL COMMENT '留言',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `xname` varchar(20) DEFAULT NULL COMMENT '下单人',
  `zt` varchar(50) DEFAULT NULL COMMENT '状态',
  `total` varchar(50) DEFAULT NULL COMMENT '总计',
  `kuaidi` varchar(50) DEFAULT NULL COMMENT '快递名称',
  `knumber` varchar(50) DEFAULT NULL COMMENT '快递编号',
  `receiver` varchar(20) DEFAULT NULL COMMENT '收货人',
  `th` int(2) DEFAULT '0' COMMENT '是否退货',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('29', '2018012220331611', '11', '19@16@', '2@1@', '男', '山东', '15236222222', 'dkf@152.com', '特快专递', '支付宝', '', '2018-09-29 17:57:08', '333', '已收货', '733', '中通物流', '3333', '李明', '1');
INSERT INTO `orders` VALUES ('28', '201801221916488', '8', '19@17@', '2@2@', '男', '详细地址详细地址', '15236222222', 'dkf@152.com', '站点自提', '支付宝', '', '2018-09-29 17:57:08', '1', '已收货', '1360', '中通物流', '343434', '夺要', '1');
INSERT INTO `orders` VALUES ('27', '201801221850168', '8', '19@17@', '2@2@', '男', '详细地址详细地址', '15236222222', 'dkf@152.com', '站点自提', '支付宝', '', '2018-09-29 17:57:08', '1', '已收货', '1360', '中通物流', '343434', '夺要', '1');
INSERT INTO `orders` VALUES ('30', '201809291634018', '8', '19@', '1@', '男', '详细地址详细地址', '15236222222', 'dkf@152.com', '站点自提', '支付宝', '', '2018-09-29 16:34:01', '1', '已收款', '200', null, '', '夺要', '0');
INSERT INTO `orders` VALUES ('31', '201809291636208', '8', '19@', '1@', '男', '详细地址详细地址', '15236222222', 'dkf@152.com', '站点自提', '支付宝', '', '2018-09-29 17:57:08', '1', '未付款', '200', null, '', '夺要', '0');
INSERT INTO `orders` VALUES ('32', '2018092916370512', '12', '17@', '1@', '男', '4', '15236222222', '2333@er.com', '站点自提', '支付宝', '', '2018-09-29 17:57:08', 'ggg', '已收款', '480', null, '', '夺要', '0');
INSERT INTO `orders` VALUES ('34', '2018092917554913', '13', '', '', '男', '88', '88', '88@qq.com', '站点自提', '支付宝', '', '2018-09-29 17:57:08', '888', '已收款', '200', null, null, '888', '0');
INSERT INTO `orders` VALUES ('35', '2018092917570813', '13', '11@', '1@', '男', '88', '88', '88@qq.com', '站点自提', '支付宝', '', '2018-09-29 17:57:08', '888', '已发货', '343', '顺丰', '12222', '888', '0');
INSERT INTO `orders` VALUES ('36', '2018092918052313', '13', '12@@', '1@@', '男', '88', '88', '88@qq.com', '站点自提', '支付宝', '', '2018-09-29 18:05:23', '888', '已发货', '3000', '顺丰', '11111', '888', '0');

-- ----------------------------
-- Table structure for `ordersta`
-- ----------------------------
DROP TABLE IF EXISTS `ordersta`;
CREATE TABLE `ordersta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordersid` int(11) NOT NULL DEFAULT '0' COMMENT '订单号',
  `goodid` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `price` decimal(11,2) DEFAULT '0.00' COMMENT '商品价格',
  `nums` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `addtime` date NOT NULL,
  `userid` varchar(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `categoryid` int(11) NOT NULL DEFAULT '0' COMMENT '分类id',
  `zt` varchar(11) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ordersta
-- ----------------------------
INSERT INTO `ordersta` VALUES ('1', '20', '19', '200.00', '1', '2018-09-29', '8', '2', null);
INSERT INTO `ordersta` VALUES ('2', '21', '19', '200.00', '1', '2018-09-29', '8', '2', null);
INSERT INTO `ordersta` VALUES ('3', '21', '10', '343.00', '3', '2018-09-29', '8', '2', null);
INSERT INTO `ordersta` VALUES ('4', '0', '19', '200.00', '1', '2018-09-29', '', '2', '未付款');
INSERT INTO `ordersta` VALUES ('5', '24', '19', '200.00', '2', '2018-09-29', '', '2', '未付款');
INSERT INTO `ordersta` VALUES ('6', '25', '17', '480.00', '2', '2018-09-29', '8', '4', '未付款');
INSERT INTO `ordersta` VALUES ('7', '25', '19', '200.00', '2', '2018-09-29', '8', '2', '未付款');
INSERT INTO `ordersta` VALUES ('8', '26', '19', '200.00', '1', '2018-09-29', '8', '2', '未付款');
INSERT INTO `ordersta` VALUES ('9', '27', '19', '200.00', '2', '2018-09-29', '8', '2', '已退货');
INSERT INTO `ordersta` VALUES ('10', '27', '17', '480.00', '2', '2018-09-29', '8', '4', '已退货');
INSERT INTO `ordersta` VALUES ('11', '28', '19', '200.00', '2', '2018-09-29', '8', '2', '已退货');
INSERT INTO `ordersta` VALUES ('12', '28', '17', '480.00', '2', '2018-09-29', '8', '4', '已退货');
INSERT INTO `ordersta` VALUES ('13', '29', '19', '200.00', '2', '2018-09-29', '11', '2', '已退货');
INSERT INTO `ordersta` VALUES ('14', '29', '16', '333.00', '1', '2018-09-29', '11', '3', '已退货');
INSERT INTO `ordersta` VALUES ('15', '30', '19', '200.00', '1', '2018-09-29', '8', '2', '已收款');
INSERT INTO `ordersta` VALUES ('16', '31', '19', '200.00', '1', '2018-09-29', '8', '2', '未付款');
INSERT INTO `ordersta` VALUES ('17', '32', '17', '480.00', '1', '2018-09-29', '12', '4', '已收款');
INSERT INTO `ordersta` VALUES ('18', '35', '11', '343.00', '1', '2018-09-29', '13', '2', '已发货');
INSERT INTO `ordersta` VALUES ('19', '36', '12', '3000.00', '1', '2018-09-29', '13', '2', '已发货');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(64) NOT NULL COMMENT '用户名',
  `nickname` varchar(50) NOT NULL COMMENT '妮称',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` varchar(50) DEFAULT NULL COMMENT 'email地址',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `img` varchar(255) DEFAULT NULL COMMENT '头像',
  `sex` varchar(255) DEFAULT NULL COMMENT '性别',
  `tel` varchar(50) DEFAULT NULL COMMENT '电话号',
  `address` varchar(50) DEFAULT NULL COMMENT '地址',
  `status` int(2) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('10', '222', '夺要', '222', 'dkf@152.com', '2018-09-29 17:57:08', null, '男', '15236222222', '详细地址详细地址', '0');
INSERT INTO `user` VALUES ('8', '1', '夺要', '1', 'dkf@152.com', '2018-09-29 17:57:08', null, '男', '15236222222', '详细地址详细地址', '0');
INSERT INTO `user` VALUES ('9', '5', '夺要', '5', '', '2018-09-29 17:57:08', '9690470.jpg', '男', '15236222222', '详细地址详细地址', '0');
INSERT INTO `user` VALUES ('3', '444444', '李明', '73882ab1fa529d7273da0db6b49cc4f3', 'dk4f@152.com', '2018-09-29 17:57:08', '8003772.jpg', '男', '15236222222', '详细地址详细地址', '0');
INSERT INTO `user` VALUES ('4', '12121', '李明', 'de872154ffbf91a5dcc0e539dd2d5106', 'dkf1@152.com', '2018-09-29 17:57:08', null, '男', '15236222222', '', '0');
INSERT INTO `user` VALUES ('5', 'ffffff', '李明w11', 'eed8cdc400dfd4ec85dff70a170066b7', '', '2018-09-29 17:57:08', null, '男', '15236222222', '详细地址详细地址', '0');
INSERT INTO `user` VALUES ('6', '777777', '王红', 'f63f4fbc9f8c85d409f2f59f2b9e12d5', '', '2018-09-29 17:57:08', null, '男', '15236222222', '小区东路20号', '0');
INSERT INTO `user` VALUES ('7', 'ds', 'dfsd', '522748524ad010358705b6852b81be4c', '', '2018-09-29 17:57:08', null, '男', '15236222222', '详细地址详细地址', '0');
INSERT INTO `user` VALUES ('11', '333', '李明', '333', '', '2018-09-29 17:57:08', '6085731.jpg', '男', '15236222222', '山东', '0');
INSERT INTO `user` VALUES ('12', 'ggg', '夺要', 'ggg', '2333@er.com', '2018-09-29 17:57:08', null, '男', '15236222222', '4', '0');
INSERT INTO `user` VALUES ('13', '888', '888', '888', '88@qq.com', '2018-09-29 17:57:08', null, '男', '88', '88', '0');
