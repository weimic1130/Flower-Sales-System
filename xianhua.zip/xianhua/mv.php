<?php 
	include_once("header.php");
	$articleA = db_get_row("select * from content1 where id=".$_REQUEST["id"]);
	db_query("update content1 set apv=apv+1 where id=".$_REQUEST["id"]);
	$cat_title = "网站公告";
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("left.php"); ?>
    </td>
    <td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31" class="sort"><a href="index.php">首页</a> &gt;&gt; <?php echo $cat_title;?></td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td height="30" align="center" class="line"><?php echo $articleA["title"];?></td>
                  </tr>
                  <tr>
                    <td height="30" align="center" class="line"><?php echo $articleA['addtime'];?> 点击：<?php echo $articleA["apv"];?></td>
                  </tr>
                  
                  <tr>
                    <td align="left"><div style="margin:20px; line-height:23px;"><?php echo $articleA['content']?></div></td>
                  </tr>
                </table>

        </td>
      </tr>
    </table></td>
  </tr>
</table>
<?php
	include_once("footer.php");
?>