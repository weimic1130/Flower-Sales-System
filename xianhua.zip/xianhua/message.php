<?php 
	include_once("header.php");
	$page = $_REQUEST["page"]?$_REQUEST["page"]:"1";
	$list = db_get_page("select * from message where isno=1 order by addtime desc", $page,9);
	if ($page*1>$list["page"]*1){
		$page = $list["page"];
	}
	$Page = new PageWeb($list["total"],$list["page_size"], "", $page);
	$page_show = $Page->show(); 
?>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin:10px auto;">
  <tr>
    <td width="240" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0;">
<?php include_once("left.php"); ?></td>
<td width="10" valign="top">&nbsp;</td>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"  class="sort"><a href="index.php">首页</a> &gt;&gt; 在线留言</td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <table width="100%" border="0" cellpadding="6" cellspacing="1">
            <tr>
              <td width="90%" height="30">
        <?php
		foreach($list["data"] as $row) {
		?>
        		<link href="<?php echo __PUBLIC__;?>/css/book.css" rel="stylesheet" type="text/css" />
    			<div class="book">
                    <div class="face"><?php if (!db_get_val("user",$row["userid"],"img")){?>
						<img src="<?php echo __PUBLIC__;?>/images/avatar.png" width="60"  height="60"/>
					<?php }else{ ?>
						<img src="<?php echo __PUBLIC__;?>/Upload/<?php echo db_get_val("user",$row["userid"],"img");?>" width="60"  height="60" />
					<?php } ?></div>
                    <div class="text">
                        <div class="div">
                            <div class="icon"></div>
                            <div class="base"><span><?php echo $row['addtime'];?></span><?php echo db_get_val("user",$row["userid"],"account");?></div>
                            <div class="content"><?php echo $row['content'];?></div>
                            <?php if(!$row['recontent']==""){?><div class="reply"><strong>管理回复：</strong><?php echo $row['recontent'];?></div><?php } ?>
                        </div>
                    </div>
                </div>
    <?php } ?><table width="100%" align="center">

                 <tr>
              <td align="center"><?php echo $page_show;?></td>
            </tr></table>
    </td>
        </tr>
      </table>
      <table width="100%" border="0" cellpadding="6" cellspacing="1">
      <form  method="post" role="form" name="form1" action="?act=add">
            <tr>
              <td width="28%" height="30" align="right" bgcolor="#f1f1f1">发表留言：</td>
              <td width="72%" align="left"  bgcolor="#f1f1f1"><textarea name="content" cols="60" rows="4" class="wenbenkuang" style="height:80px;"></textarea></td>
            </tr>
			<tr>
              <td height="30" bgcolor="#f1f1f1"></td>
              <td height="30" bgcolor="#f1f1f1"><button class="tbutton" type="submit">提交</button></td>
            </tr>
           </form>
          </table>
    </td>
      </tr>
    </table>
        </td></tr>

    </table>
<?php 
	$act = !empty($_GET['act']) ? trim($_GET['act']) : '';
	if($act == 'add')
	{
		if (!$_SESSION["id"]) {
			goBakMsg("登录后才可提交！");
			die;
		}
		$data1 = array();
		$data1["userid"] = "'".$_SESSION["id"]."'";	
		$data1["content"] = "'".$_POST["content"]."'";
		db_add("message",$data1);
		urlMsg("提交成功,请等待回复", "message.php");
	}
	include_once("footer.php");
?>