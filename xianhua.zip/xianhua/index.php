<?php 
	include_once("header.php");
?>
<table width="1000" border="0" cellpadding="0" cellspacing="0" align="center" style="margin:10px auto;">
  <tr>
    <td valign="top">
    <script type="text/javascript" src="<?php echo __PUBLIC__;?>/js/jquery-1.8.0.min.js"></script>
<script src="<?php echo __PUBLIC__;?>/js/jquery.slider.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo __PUBLIC__;?>/css/huandeng.css"/>
<script type="text/javascript">
	jQuery(document).ready(function ($) {
		$(".slider").slideshow({
		width: 733,
		height: 240,
		transition: ['bar', 'Rain', 'square', 'squareRandom', 'explode']
		});
	});
</script>
<div class="slider">
<div><img src="<?php echo __PUBLIC__;?>/images/banner1.jpg" width="733" height="240" /></div>
<div><img src="<?php echo __PUBLIC__;?>/images/banner2.jpg" width="733" height="240" /></div>
</div>
    </td>
    <td width="12" valign="top">&nbsp;</td>
    <td width="255" valign="top">
    <table width="255" border="0" cellpadding="0" cellspacing="0" align="center" style="border: #CCC 1px solid;">
        <tr>
          <td valign="top">
            <table width="100%" height="30" border="0" cellpadding="0" cellspacing="0" class="nav1">
            <tr>
              <td align="left" class="con2">&nbsp;&nbsp;&nbsp;<b>网站公告</b></td>
              <td width="59" align="center" valign="middle" class="more"><a href="list.php?pid=3">更多>></a></td>
            </tr>
          </table>
          <table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr><td height="5"></td></tr>
				<?php
						$new_art1 = db_get_all("select * from content1 order by id desc limit 7");
					 foreach($new_art1 as $row3) {?>
					
					
          	<tr >
            <td height="28" align="left" valign="middle"  >&nbsp;&nbsp;&middot;&nbsp;<a href="mv.php?id=<?php echo $row3['id'];?>"><?php echo $row3['title'];?></a></td>
            </tr>
    <?php
						}
					?><tr><td height="5"></td></tr>
    </table></td>
        </tr>
    </table>
    </td>
  </tr>
</table>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:10px;">
  <tr>
    <td valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="31"><table width="100%" height="30" border="0" cellpadding="0" cellspacing="0" class="nav1">
            <tr>
              <td align="left" class="con2">&nbsp;&nbsp;&nbsp;<b>最新鲜花</b></td>
              <td width="59" align="center" valign="middle" class="more"><a href="goods.php">更多>></a></td>
            </tr>
          </table></td>
      </tr>
      <tr>
        <td height="" valign="top" bgcolor="#FFFFFF" style="border:1px solid #e0e0e0; padding:10px; line-height:25px;">
        <?php
						$new_art1 = db_get_all("select * from goods where status=0 order by id desc limit 8");
					 foreach($new_art1 as $row) {?><div style="float:left; margin:5px; width:231px;"><table width="223" height="89" border="0" cellpadding="0" cellspacing="0" style="border:#CCC 1px solid; margin:10px;">
							<tr>
								<td align="center" valign="middle">
                                <a href="goodshow.php?id=<?php echo $row['id'];?>&categoryid=<?php echo $row['categoryid'];?>"><?php
						if (!$row["img"]){
					?>
						<img src="<?php echo __PUBLIC__;?>/images/avatar.png" width="223"  height="223"/>
					<?php }else{ ?>
						<img src="<?php echo __PUBLIC__;?>/Upload/<?php echo $row["img"];?>" width="223"  height="223" />
					<?php } ?></a>
							</td>
                            <tr><td height="30" align="center"><?php echo $row['title'];?></td></tr>
                            <tr><td height="30" align="center">价格:<span style="color:#e60432"><?php echo $row['sprice'];?></span>元  <a href="addcart.php?id=<?php echo $row['id'];?>"><img src="<?php echo __PUBLIC__;?>/images/cart-icon.png"  height="30" width="30"  align="absmiddle"/></a></td></tr>
			</table></div><?php
                }
			?>

        </td>
      </tr>
    </table></td>
  </tr>
</table>
<?php
	include("footer.php");
?>